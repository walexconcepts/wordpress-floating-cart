===Floating Cart for WooCommerce===
Contributors: Awodeyi Adewale Emmanuel
Donate link: https://izzumes.com/ 
Tags: basket, cart, products, floating, shopping, checkout,responsive
Requires at least: 5.4
Tested up to: 6.1.1
Stable tag: 2.0
Requires PHP: 5.2.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Floating Cart for WooCommerce with many styles . It is great-looking and responsive, and absolutely free. Please visit [demo](https://walexconcepts.com/wordpress/).

== Description ==
<p>
Floating Cart for WooCommerce with many styles . It is great-looking and responsive, and absolutely free. Please visit [demo](https://walexconcepts.com/wordpress/).
</p>

Free Version features:
<p>
<ul>
<li>* Floating Cart for WooCommerce looks responsive on any device.</li>
<li>* No backend or admin functionality .</li>
<li>* No automatic cart update. As a result, page refresh required.</li>
<li>* Coding skills NOT required.</li>
<li>* Theme modifications NOT required.</li>
</ul>
</p>
All

Premium Features:
<p>
<ul>
<li>* Floating Cart for WooCommerce look responsive on any device. </li>
<li>* Turn ON / OFF button to hide or show  Update button and Automatically Update Cart on Quantity Change:. </li>
<li>* You can use it as simple cart with admin options to configure backgroud color.</li>
<li>* You can use it as simple cart with admin options to configure Basket-color.</li>
<li>* You can use it as simple cart with admin options to configure position .</li>
<li>* The Floating Cart for WooCommerce displays results in several 6 options at frontend 
which entails Home page, All pages, All pages except cart e.t,c</li>
<li>* Position – You can simply set the position of the Floating Cart for WooCommerce(right ot left)..</li>
</ul>
</p>




== Installation ==
<p>
<ul>
<li>1. Upload files of Floating Cart for WooCommerce `/wp-content/plugins/`</li> 
<li>2. Activate the plugin through the 'Plugins' menu in WordPress</li>
<li>3. Premium Features, click 'Floating Cart for WooCommerce' menu in WordPress to open Floating Cart for WooCommerce admin page.</li>
<li>4. No Shotcode or Widget required</li>
</ul>
</p>

== Frequently Asked Questions ==
= Does Floating Cart for WooCommerce work with any Wordpress theme? =

Yes, it does. You can use it with any Wordpress theme.

= Do I get free support for this free plugin? = 
Yes, we can provide support via email and chat if needed. 

== Screenshots ==
1. Screenshot-1 Floating Cart for WooCommerce admin page configuration or back-end 
2. Screenshot-2 Front-end - Results floating
3. Screenshot-3 Responsive layout - mobile
4. Screenshot-4 Responsive layout - tablet  
 

== Changelog ==
<p>
<ul>
= 1.0 =
<li>* roll out (Feb, 27, 2023)</li>
</ul>
</p>
