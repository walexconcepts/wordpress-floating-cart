<?php
	
?>
<div style="float:none" class="well-3 center-block-3 col-md-4-3">
<h3>Help - User Guide</h3>

== <b>Description</b> ==
<p>
Thank you for installing Floating Cart for WooCommerce. Please visit [demo](https://walexconcepts.com/wordpress/).
</p>


Free Version features:
<p>
<ul>
<li>* Floating Cart for WooCommerce looks responsive on any device.</li>
<li>* No backend or admin functionality .</li>
<li>* No automatic cart update. As a result, page refresh required.</li>
<li>* Coding skills NOT required.</li>
<li>* Theme modifications NOT required.</li>

</ul>
</p>
All

Premium Features:
<p>
<ul>
<li>* Floating Cart for WooCommerce look responsive on any device. </li>
<li>* Turn ON / OFF button to hide or show  Update button and Automatically Update Cart on Quantity Change:. </li>
<li>* You can use it as simple cart with admin options to configure backgroud color.</li>
<li>* You can use it as simple cart with admin options to configure Basket-color.</li>
<li>* You can use it as simple cart with admin options to configure position .</li>
<li>* The Floating Cart for WooCommerce displays results in several 6 options at frontend 
which entails Home page, All pages, All pages except cart e.t,c</li>
<li>* Position – You can simply set the position of the Floating Cart for WooCommerce(right ot left)..</li>
</ul>
</p>
